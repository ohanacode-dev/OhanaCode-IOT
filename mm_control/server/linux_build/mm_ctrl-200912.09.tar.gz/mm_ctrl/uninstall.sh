#!/bin/bash

APPDIR=$PWD
SHORTCUT_NAME=$HOME/.local/share/applications/mm_ctrl.desktop

cd $HOME

rm -f $SHORTCUTFILE
rm -rf $APPDIR



